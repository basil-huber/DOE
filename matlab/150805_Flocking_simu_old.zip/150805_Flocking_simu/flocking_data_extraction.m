% Read from file

filepath = 'Results/';

maxvhc = 50;
c1Extract = 40;
c2Extract = 75;

total = [];
for i = 1:12
    if i == 1
        dExtract = 80000;
        aExtract = 100;
        bExtract = 900;
    elseif i == 2
        dExtract = 140000;
        aExtract = 100;
        bExtract = 900;
    elseif i == 3
        dExtract = 80000;
        aExtract = 900;
        bExtract = 900;
    elseif i == 4
        dExtract = 140000;
        aExtract = 900;
        bExtract = 900;
    elseif i == 5
        dExtract = 11000;
        aExtract = 100;
        bExtract = 500;
    elseif i == 6
        dExtract = 11000;
        aExtract = 100;
        bExtract = 1300;
    elseif i == 7
        dExtract = 110000;
        aExtract = 500;
        bExtract = 500;
    elseif i == 8
        dExtract = 11000;
        aExtract = 1300;
        bExtract = 1300;
    elseif i == 9
        dExtract = 80000;
        aExtract = 300;
        bExtract = 500;
    elseif i == 10
        dExtract = 80000;
        aExtract = 700;
        bExtract = 1300;
    elseif i == 11
        dExtract = 140000;
        aExtract = 300;
        bExtract = 500;
    elseif i == 12
        dExtract = 110000;
        aExtract = 533;
        bExtract = 966;
    elseif i == 13
        dExtract = 140000;
        aExtract = 700;
        bExtract = 1300;
    end
    
    total(i).d = dExtract/100;
    total(i).a = aExtract/100;
    total(i).b = bExtract/100;
    total(i).c1 = c1Extract/100;
    total(i).c2 = c2Extract/100;
    
    fileid = fopen([filepath 'Stats_' int2str(maxvhc) '_' int2str(dExtract) '_' int2str(aExtract) '_' int2str(bExtract) '_' int2str(c1Extract) '_' int2str(c2Extract) '.txt']);
    text = textscan(fileid,'%f');
    if(size(text{:,:}))
        total(i).B = dlmread([filepath 'Stats_' int2str(maxvhc) '_' int2str(dExtract) '_' int2str(aExtract) '_' int2str(bExtract) '_' int2str(c1Extract) '_' int2str(c2Extract) '.txt'], '\t');
    end
    fclose('all');
    
    
end

baseline = [];
fileid = fopen([filepath 'Stats_1_140000_700_1300_40_75.txt']);
text = textscan(fileid,'%f');
if(size(text{:,:}))
    baseline.B = dlmread([filepath 'Stats_1_140000_700_1300_40_75.txt'], '\t');
end
fclose('all');

%%
stat = [];
for i = 1:size(total,2)
    B = total(i).B;
    
    stat(i).simuStop = B(1,1);
    stat(i).alt_prob = B(1,2);
    stat(i).elapsed_time = B(1,3);
    stat(i).total_jerk = B(1,4);
    stat(i).number_collisions = B(1,5);
    stat(i).number_near_miss = B(1,6);
    stat(i).min_distance = B(1,7);
    stat(i).jerk = B(2,1:maxvhc);
    stat(i).arrival_time = B(3,1:maxvhc);
    stat(i).min_distance = B(4,:);
end

B = baseline.B;
statBaseline = [];
statBaseline.simuStop = B(1,1);
statBaseline.alt_prob = B(1,2);
statBaseline.elapsed_time = B(1,3);
statBaseline.total_jerk = B(1,4);
statBaseline.number_collisions = B(1,5);
statBaseline.number_near_miss = B(1,6);
statBaseline.min_distance = B(1,7);
statBaseline.jerk = B(2,1);
statBaseline.arrival_time = B(3,1);
statBaseline.min_distance = B(4,:);

%% Matrix form

number_of_collisions = cell2mat({stat(:).number_collisions})';

meanArrivalTime = zeros(size(stat,2),1);
for i = 1:size(stat,2)
    meanArrivalTime(i) = mean(stat(i).arrival_time);
end
meanArrivalTime = meanArrivalTime / statBaseline.arrival_time ;

meanJerk = zeros(size(stat,2),1);
for i = 1:size(stat,2)
    meanJerk(i) = mean(stat(i).jerk);
end
meanJerk = meanJerk / statBaseline.jerk;

d = cell2mat({total(:).d})';
a = cell2mat({total(:).a})';
b = cell2mat({total(:).b})';

matrixExperiments = [d a b meanArrivalTime meanJerk];

%%
figure
plot(1:12,number_of_collisions)
figure
plot(1:12,meanArrivalTime,'r')
figure
plot(1:12,meanJerk,'g')



